import pymongo


def mongoConnect(dbname, collection = None):
    connectdb = pymongo.MongoClient(f"mongodb://alham0046:alham789@ac-2ybb09o-shard-00-00.odsdwox.mongodb.net:27017,ac-2ybb09o-shard-00-01.odsdwox.mongodb.net:27017,ac-2ybb09o-shard-00-02.odsdwox.mongodb.net:27017/?ssl=true&replicaSet=atlas-vwia5y-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0/{dbname}")
    if connectdb:
        print("connection success")
        if not collection:
            return connectdb[dbname]
        elif collection:
            if collection not in connectdb[dbname].list_collection_names():
                return None
            return connectdb[dbname][collection]