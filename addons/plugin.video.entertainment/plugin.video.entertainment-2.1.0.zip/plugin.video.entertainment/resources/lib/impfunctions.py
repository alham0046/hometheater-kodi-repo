import sys
import urllib.parse
import xbmc
import xbmcgui

addon_handle = int(sys.argv[1])

base_url = sys.argv[0]

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def log(find, message = "The default value is"):
    xbmc.log(f"{message}: {find}", xbmc.LOGDEBUG)

def show_error_dialog(title, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)