import sqlite3
import os


def tvCache(channelList = []):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    conn = sqlite3.connect(os.path.join(path,"tvCache.db"))
    cur = conn.cursor()
    fileCache = """CREATE TABLE IF NOT EXISTS TVshowCache (
                    Channel_Name TEXT,
                    Show_Name TEXT,
                    Show_Poster TEXT,
                    Show_Backdrop TEXT,
                    Show_Url TEXT,
                    Show_Status)"""
    cur.execute(fileCache)
    conn.commit()
    for chDetail in channelList:
        cur.execute("SELECT * FROM TVshowCache WHERE Show_Name = ?", (chDetail["showname"],))
        if cur.fetchone():
            get_data = cur.execute("SELECT * FROM TVshowCache")
            for i in get_data:
                print(i)
            continue
        cur.execute(""" INSERT INTO TVshowCache (
                    Channel_Name,
                    Show_Name,
                    Show_Poster,
                    Show_Backdrop,
                    Show_Url,
                    Show_Status
                    ) VALUES (?,?,?,?,?,?)""", (chDetail["chname"], chDetail["showname"], chDetail["poster"], chDetail["backdrop"], chDetail["url"], chDetail["Show_Status"]))
        conn.commit()
        print(chDetail["showname"])
    
    conn.close()
def tvEpisodeCache(episodeList = []):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    conn = sqlite3.connect(os.path.join(path,"tvEpisodes.db"))
    cur = conn.cursor()
    fileCache = """CREATE TABLE IF NOT EXISTS tvEpisodes (
                    channelName TEXT,
                    showName TEXT,
                    episodeTitle TEXT,
                    episodeImg TEXT,
                    episodeDate TEXT,
                    episodeUrl TEXT)"""
    cur.execute(fileCache)
    conn.commit()
    for epiDetail in episodeList:
        cur.execute(""" INSERT INTO tvEpisodes VALUES (?,?,?,?,?,?)""", (epiDetail["channelname"], epiDetail["showname"], epiDetail["title"] , epiDetail["img"], epiDetail["episodedate"], epiDetail["EpisodeUrl"]) if isinstance(epiDetail, dict) else epiDetail)
        conn.commit()
        print(epiDetail["title"])
    conn.close()


def moviesCache(dbname, tablename, moviesList = []):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    conn = sqlite3.connect(os.path.join(path,dbname))
    keysList = moviesList[0].keys()
    keys = ", ".join([f"{key} TEXT" for key in keysList])
    cur = conn.cursor()
    fileCache = f"CREATE TABLE IF NOT EXISTS {tablename} ({keys})"
    cur.execute(fileCache)
    conn.commit()
    for movies in moviesList:
        values = movies.values()
        cur.execute(f"INSERT INTO {tablename} VALUES ({', '.join(['?'] * len(keysList))})", (tuple(values)))
        conn.commit()
    conn.close()


def updateDatabase(dbname, tablename, updatevar, updatevalue, whereclause, condition):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    conn = sqlite3.connect(os.path.join(path, dbname))
    cur = conn.cursor()
    cur.execute(f"UPDATE {tablename} SET {updatevar} = ? WHERE {whereclause} = ?", (updatevalue, condition))
    conn.commit()
    conn.close()

def updateDatabaseMulti(dbname, tablename, updateDict, whereclause, condition):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    conn = sqlite3.connect(os.path.join(path, dbname))
    cur = conn.cursor()
    # Generate the SET part of the SQL statement dynamically
    set_clause = ', '.join([f"{column} = ?" for column in updateDict.keys()])
    update_values = tuple(updateDict.values())
    cur.execute(f"UPDATE {tablename} SET {set_clause} WHERE {whereclause} = ?", update_values + (condition,))
    conn.commit()
    conn.close()

def dropTable(dbname, tablename):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    if os.path.exists(os.path.join(path, dbname)):
        conn = sqlite3.connect(os.path.join(path, dbname))
        cur = conn.cursor()
        cur.execute(f"DROP TABLE IF EXISTS {tablename}")
        conn.commit()
        conn.close()

def getdb(dbname, tablename, condition = None, whereclause = None, select = "*", orderby = None, like = False):
    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    if os.path.exists(os.path.join(path, dbname)):
        conn = sqlite3.connect(os.path.join(path, dbname))
        cur = conn.cursor()
        # Check if table exists
        cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name=?", (tablename,))
        if cur.fetchone() is None:
            return []  # Return empty list if table does not exist
        if orderby:
            shows = cur.execute(f"SELECT {select} FROM {tablename} WHERE {whereclause} = ? ORDER BY {orderby}", (condition,))
        elif like == True:
            shows = cur.execute(f"SELECT {select} FROM {tablename} WHERE {whereclause} LIKE ?", (condition,))
        elif whereclause is None:
            shows = cur.execute(f"SELECT {select} FROM {tablename}")
        else:
            shows = cur.execute(f"SELECT {select} FROM {tablename} WHERE {whereclause} = ?", (condition,))
        return shows.fetchall()
    else:
        return []

# dtb = getdb("tvCache.db", "TVshowCache", "ZEE TV")
# if not dtb:
#     print("success")
# else:
#     print(dtb)
        
