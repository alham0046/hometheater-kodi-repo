import sys
import urllib.parse
import xbmc
import xbmcgui
from resources.utils.db_util import getdb, dropTable, updateDatabaseMulti
from resources.lib.connectMongo import mongoConnect

addon_handle = int(sys.argv[1])

base_url = sys.argv[0]

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def log(find, message = "The default value is"):
    xbmc.log(f"{message}: {find}", xbmc.LOGDEBUG)

def show_dialog(title, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)

def refreshContainer(mode, **params):
    # Start with the base URL
    base_url = f'plugin://plugin.video.entertainment/?mode={mode}'
    
    # Add the additional parameters dynamically
    if params["url"] and isinstance(params['url'], list):
        for item in params["url"]:
            # Build the full URL by adding the item to the base URL
            full_url = f"{base_url}&url={item}"
            # Add any additional parameters to the URL
            if len(params) > 1:  # Exclude 'url' from params
                param_str = "&".join([f"{key}={value}" for key, value in params.items() if key != 'url'])
                full_url = f"{full_url}&{param_str}"
            # Refresh container and update library
            xbmc.executebuiltin(f'Container.Update("{full_url}", replace)')
        xbmc.executebuiltin(f'UpdateLibrary(video,,true)')
    else:
        if params:
            param_str = "&".join([f"{key}={value}" for key, value in params.items()])
            full_url = f"{base_url}&{param_str}"
        else:
            full_url = base_url
    
    # Execute the built-in Kodi functions
    xbmc.executebuiltin(f'Container.Update("{full_url}", replace)')
    xbmc.executebuiltin(f'UpdateLibrary(video,"{full_url}",true)')



def refresh_link(filterValue, type):
    dbname = "movieslist.db" if type == "movie" else "tvEpisodes.db"
    filterfind = "movieName" if type == 'movie' else 'episodeTitle'
    collectionName = "moviesList" if type == 'movie' else 'episodeList'
    tablename = dbname.split(".db")[0]
    hometheater_movieList = mongoConnect("Hometheater", collectionName)
    findRefreshDataMongo = hometheater_movieList.find_one({filterfind : filterValue}, {"_id" : 0})
    findRefreshDatasql = getdb(dbname=dbname, tablename=tablename, whereclause=filterfind, condition=filterValue)
    mode = "get_movies" if type == 'movie' else 'get_Episodes'
    url = findRefreshDataMongo["moviePlatform"].lower() if type == 'movie' else findRefreshDataMongo["showName"]
    updatevalues = {}
    for i, (key,value) in enumerate(findRefreshDataMongo.items(), start=0):
        if value != findRefreshDatasql[0][i]:
            updatevalues[key] = ", ".join(value) if isinstance(value, list) else value
    updateDatabaseMulti(dbname=dbname, tablename=tablename, updateDict=updatevalues, whereclause=filterfind, condition=filterValue)
    refreshContainer(mode=mode, url=url)


def restore_database(dbname, tablename):
    log(message="value of restore db is", find=dbname)
    dropTable(dbname=dbname, tablename=tablename)
    xbmc.executebuiltin('ReloadSkin()')