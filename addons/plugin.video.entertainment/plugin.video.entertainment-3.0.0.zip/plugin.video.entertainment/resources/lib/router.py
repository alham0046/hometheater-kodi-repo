import urllib.parse
import xbmc

def routing(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    xbmc.log(f"params string is: {paramstring}", xbmc.LOGDEBUG)
    if params:
        if params['mode'] == 'get_channel':
            from resources.lib.tvshowsdatabase import get_channel
            get_channel()
        elif params['mode'] == "get_movieplatform":
            from resources.lib.moviesdatabase import get_movieplatform
            get_movieplatform()
        elif params['mode'] == "get_webshowsplatform":
            from resources.lib.webshows import get_webshowsplatform
            get_webshowsplatform()
        elif params['mode'] == 'get_shows':
            from resources.lib.tvshowsdatabase import get_shows
            action = params.get('action', 'None')
            get_shows(params['url'], action)
        elif params['mode'] == 'get_Episodes':
            from resources.lib.tvshowsdatabase import get_Episodes
            get_Episodes(params['url'])
        elif params['mode'] == 'play_video':
            from resources.lib.tvshowsdatabase import play_video
            play_video(params['url'])
        elif params['mode'] == 'get_movies':
            from resources.lib.moviesdatabase import get_moviesList
            action = params.get('action', 'None')
            get_moviesList(params['url'], action)
        elif params['mode'] == 'get_webshows':
            from resources.lib.webshows import get_webshowsList
            get_webshowsList(params['url'])
        elif params['mode'] == 'play_movie':
            from resources.lib.moviesdatabase import play_movie
            play_movie(params['url'])
        elif params['mode'] == 'play_webshow':
            from resources.lib.webshows import play_webshow
            play_webshow(params['url'])
        elif params['mode'] == 'open_webshow':
            from resources.lib.webshows import open_webshow
            open_webshow(params['url'] ,params['seriesName'], params['lastSeason'])
        elif params['mode'] == 'set_status':
            from resources.lib.tvshowsdatabase import set_status
            set_status(params['showname'], params['status'])
        elif params['mode'] == 'airing_shows':
            from resources.lib.tvshowsdatabase import airing_shows
            airing_shows()
        elif params['mode'] == 'refresh_link':
            from resources.lib.impfunctions import refresh_link
            refresh_link(params["filterValue"], params['type'])
        elif params['mode'] == 'search_movies':
            from resources.lib.moviesdatabase import search_movies
            search_movies(params["query"])
        elif params['mode'] == 'restore_database':
            from resources.lib.impfunctions import restore_database
            restore_database(params["dbname"], params["tablename"])
    else:
        from resources.lib.mainMenu import main_menu
        xbmc.log(f"Router params: {params}", xbmc.LOGDEBUG)
        main_menu()

