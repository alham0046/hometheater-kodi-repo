import xbmcplugin
import xbmcgui
import xbmc
import xbmcaddon
from resources.lib.urlResolver import resolve_url
from resources.lib.impfunctions import build_url, addon_handle, log, refreshContainer, show_dialog as box
from resources.lib.connectMongo import mongoConnect
from resources.utils.db_util import getdb, moviesCache

popularOtts = ['netflix', 'hotstar', 'amazon prime', 'sonyliv', 'zee5', 'jiocinema', 'mxplayer']

def get_webshowsplatform():
    for ottApp in popularOtts:
        li = xbmcgui.ListItem(ottApp.upper())
        li.addContextMenuItems([("Check New Movies", f'RunPlugin({build_url({"mode": "get_webshows", "url": ottApp, "action" : "addNew"})})'), ("Restore Database", f'RunPlugin({build_url({"mode": "restore_database", "dbname" : "webShows.db", "tablename" : "webEpisodes"})})')])
        url = build_url({'mode': 'get_webshows', 'url': ottApp})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def get_webshowsList(ottApp, action = "None"):
    showsListsdb = getdb(dbname="webShows.db", tablename="showOnWeb", whereclause="ottPlatform", condition=ottApp.upper(), orderby="lastSeasonAiringDate DESC")
    def setShowDetails(webShowList):
        items = []
        for webShow in webShowList:
            showId, seriesName, ottPlatform, plot, no_of_season, _, poster, backdrop, url, lastAiringDate, _ = webShow
            li = xbmcgui.ListItem(seriesName)
            info_tag = li.getVideoInfoTag()
            li.setArt({
                'thumb' : poster,
                'icon' : poster,
                'fanart' : backdrop
            })
            # li.setProperty('VideoResolution', '1080')
            xbmcplugin.setContent(addon_handle, 'tvshows')
            info_tag.setMediaType('tvshow')
            # info_tag.setSeason(int(no_of_season))
            info_tag.setPlot(plot)
            li.setProperty('PlatformOtt', ottPlatform)
            info_tag.setPremiered(lastAiringDate)
            # li.setProperty('IsPlayable', 'true')
            li.addContextMenuItems([("Refresh Movie", f'RunPlugin({build_url({"mode": "refresh_link", "dbname" : "webShows.db", "tablename" : "showOnWeb", "filterKey" : "seriesName", "filterValue": seriesName})})')])
            showurl = build_url({'mode': 'get_season', 'url': showId})
            items.append((showurl, li, True))
                # xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=False)
        xbmcplugin.addDirectoryItems(addon_handle, items)
        xbmcplugin.endOfDirectory(addon_handle)

    if action == "None":
        if showsListsdb:
            setShowDetails(showsListsdb)
        hometheater_showsList = mongoConnect("Hometheater", "showOnWeb")
        if len(showsListsdb) != hometheater_showsList.count_documents({"ottPlatform" : ottApp.upper()}):
            showsListsdbShows = [shows[1] for shows in showsListsdb]
            # platform_filter = hometheater_showsList.find({"ottPlatform" : ottApp.upper()})
            showsListtoUpdate = [moveies for moveies in hometheater_showsList.find({"ottPlatform" : ottApp.upper(), "seriesName" : {"$nin" : showsListsdbShows}})]
            # moviesListtoUpdate = [moveies for moveies in platform_filter]
            moviesCache(dbname="webShows.db", tablename="showOnWeb", moviesList=showsListtoUpdate)
            if showsListsdb:
                refreshContainer(mode="get_webshows", url=ottApp)
            if not showsListsdb:
                showsListsdb = getdb(dbname="webShows.db", tablename="showOnWeb", whereclause="ottPlatform", condition=ottApp.upper(), orderby="lastSeasonAiringDate DESC")
                setShowDetails(showsListsdb)

def get_season(showId):
    seasonListsdb = getdb(dbname="webShows.db", tablename="showSeason", whereclause="webShowId", condition=showId, orderby="seasonName DESC")
    def setSeasonDetails(seasonList):
        items = []
        for showSeason in seasonList:
            seasonId, showId, seasonName, no_of_episodes, poster, plot, seasonNumber = showSeason
            li = xbmcgui.ListItem(seasonName)
            info_tag = li.getVideoInfoTag()
            li.setArt({
                'thumb' : poster,
            })
            info_tag.setPlot(plot)
            info_tag.setMediaType('season')
            # li.addContextMenuItems([("Refresh Movie", f'RunPlugin({build_url({"mode": "refresh_link", "dbname" : "webShows.db", "tablename" : "showOnWeb", "filterKey" : "seriesName", "filterValue": seriesName})})')])
            showurl = build_url({'mode': 'get_episodes', 'url': seasonId})
            items.append((showurl, li, True))
                # xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=False)
        xbmcplugin.addDirectoryItems(addon_handle, items)
        xbmcplugin.endOfDirectory(addon_handle)
    if seasonListsdb:
        setSeasonDetails(seasonListsdb)
    hometheater_seasonsList = mongoConnect("Hometheater", "showSeason")
    if len(seasonListsdb) != hometheater_seasonsList.count_documents({"webShowId" : showId}):
        seasonListsdbseasons = [season[2] for season in seasonListsdb] or []
        seasonListtoUpdate = [showSeasons for showSeasons in hometheater_seasonsList.find({"webShowId" : showId , "seasonName" : {"$nin" : seasonListsdbseasons}})]
        moviesCache(dbname="webShows.db", tablename="showSeason", moviesList=seasonListtoUpdate)
        if seasonListsdb:
            refreshContainer(mode="get_season", url=showId)
        if not seasonListsdb:
            seasonListsdb = getdb(dbname="webShows.db", tablename="showSeason", whereclause="webShowId", condition=showId, orderby="seasonName DESC")
            setSeasonDetails(seasonListsdb)

def get_episodes(seasonId):
    episodeListsdb = getdb(dbname="webShows.db", tablename="webEpisodes", whereclause="showSeasonId", condition=seasonId, orderby="episodeNumber")
    def setEpisodeDetails(episodeList):
        items = []
        for episode in episodeList:
            episodeId, showId, seasonIdref, episodeNumber, episodeName, plot, runtime, primired, playLink, poster = episode
            li = xbmcgui.ListItem(episodeName)
            info_tag = li.getVideoInfoTag()
            li.setArt({
                'thumb' : poster,
            })
            li.setProperty('VideoResolution', '1080')
            info_tag.setMediaType('episode')
            # li.setProperty('episode', str(episodeNumber))
            info_tag.setSeason(int(seasonIdref.split("_")[1]))
            info_tag.setEpisode(int(episodeNumber)) if episodeNumber != "Complete" else None
            info_tag.setDuration(int(runtime)*60) if runtime else info_tag.setDuration(0)
            li.setProperty('IsPlayable', 'true')
            info_tag.setPlot(plot)
            # li.addContextMenuItems([("Refresh Movie", f'RunPlugin({build_url({"mode": "refresh_link", "dbname" : "webShows.db", "tablename" : "showOnWeb", "filterKey" : "seriesName", "filterValue": seriesName})})')])
            showurl = build_url({'mode': 'play_webshow', 'url': playLink})
            items.append((showurl, li, False))
                # xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=False)
        xbmcplugin.addDirectoryItems(addon_handle, items)
        xbmcplugin.endOfDirectory(addon_handle)
    if episodeListsdb:
        setEpisodeDetails(episodeListsdb)
    hometheater_episodeList = mongoConnect("Hometheater", "webEpisodes")
    if len(episodeListsdb) != hometheater_episodeList.count_documents({"showSeasonId" : seasonId}):
        episodeListsdbseasons = [episode[3] for episode in episodeListsdb] or []
        episodeListtoUpdate = [showSeasons for showSeasons in hometheater_episodeList.find({"showSeasonId" : seasonId , "episodeNumber" : {"$nin" : episodeListsdbseasons}})]
        log(message="episodedb is", find=seasonId)
        moviesCache(dbname="webShows.db", tablename="webEpisodes", moviesList=episodeListtoUpdate)
        if episodeListsdb:
            refreshContainer(mode="get_episodes", url=seasonId)
        if not episodeListsdb:
            episodeListsdb = getdb(dbname="webShows.db", tablename="webEpisodes", whereclause="showSeasonId", condition=seasonId, orderby="episodeNumber")
            setEpisodeDetails(episodeListsdb)

def play_webshow(playLink):
    li = xbmcgui.ListItem(offscreen = True)
    li.setPath(playLink)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)