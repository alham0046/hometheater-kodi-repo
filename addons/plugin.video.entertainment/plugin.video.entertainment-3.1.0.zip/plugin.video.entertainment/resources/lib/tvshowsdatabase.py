from resources.lib.impfunctions import addon_handle, build_url, log, show_dialog as box, refreshContainer
from resources.lib.urlResolver import resolve_url
from resources.utils.db_util import getdb, tvCache, tvEpisodeCache, updateDatabase
import xbmcplugin
import xbmcgui
import concurrent.futures
import requests
from dateutil import parser
from resources.lib.connectMongo import mongoConnect

# urlmain = "https://www.yodesitv.info/"
channelList = ["STAR PLUS", "SONY TV", "STAR BHARAT", "ZEE TV", "COLORS", "SAB TV"]

def get_channel():
    for channel in channelList:
        li = xbmcgui.ListItem(channel)
        li.addContextMenuItems([("Refresh Channel", f'RunPlugin({build_url({"mode": "get_shows", "url" : channel, "action" : "addNew"})})'), ("Restore Database", f'RunPlugin({build_url({"mode": "restore_database", "dbname" : "tvEpisodes.db", "tablename" : "tvEpisodes"})})')])
        url = build_url({'mode': 'get_shows', 'url': channel})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    li = xbmcgui.ListItem("Airing Today")
    url = build_url({'mode': 'airing_shows'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def airing_shows():
    from datetime import datetime
    hometheater_episodeList = mongoConnect("Hometheater", "episodeList")
    episodesmongo = hometheater_episodeList.find({"episodeDate" : str(datetime.today().date())}, {"_id" : 0})
    episodesdb = [convert_to_str(tuple(episode.values())) for episode in episodesmongo]
    def airingDetail(episodesdb):    
        hometheater_showlist = mongoConnect("Hometheater", "ShowsList")
        showlist = hometheater_showlist.find({}, {"_id" : 0,"showName" : 1, "showBackdrop" : 1})
        showList = {shows["showName"]: shows["showBackdrop"] for shows in showlist}
        for episode in episodesdb:
            log(message="The episode is", find=episode)
            chname, shname, title, imgurl, airingDate, episodeUrl = episode
            log(message="The Airing Date is", find=airingDate)
            if isinstance(episodeUrl, list):
                episodeUrl = ", ".join(episodeUrl)
            li = xbmcgui.ListItem(shname)
            info_tag = li.getVideoInfoTag()
            li.setArt({
                'thumb' : imgurl,
                'icon' : imgurl,
                'fanart' : showList[shname]
            })
            formatted_date = parser.parse(airingDate).strftime("%d/%m/%Y")
            li.setProperty("FormattedPremiered", formatted_date)
            # log(message="get listitem", find=dir(li))
            li.setProperty('IsPlayable', 'true')
            epiUrl = build_url({'mode': 'play_video', 'url': episodeUrl })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=epiUrl, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
    if episodesdb:
        airingDetail(episodesdb)

def convert_to_str(episodeTuple):
    retVal = tuple(", ".join(value) if isinstance(value, list) else value for value in episodeTuple)
    return retVal

def get_shows(channelName, action = "None"):
    def setShowDetails(showLists):
        for showList in showLists:
            _,title, poster, backdrop, url, show_status = showList
            li = xbmcgui.ListItem(title)
            li.setArt({
                'thumb' : poster,
                'icon' : poster,
                'fanart' : backdrop
            })
            if show_status == "Airing":
                li.addContextMenuItems([("Completed", f'RunPlugin({build_url({"mode": "set_status", "showname": title, "status": "Completed"})})')])
            elif show_status == "Completed":
                li.addContextMenuItems([("Airing", f'RunPlugin({build_url({"mode": "set_status", "showname": title, "status": "Airing"})})')])
            showurl = build_url({'mode': 'get_Episodes', 'url': title})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
        episodeList([(val[1],val[4]) for val in showLists if val[0] == channelName and val[5] == "Airing"], channelName)
    if action == "addNew":
        showListsalldb = getdb(dbname="tvCache.db", tablename="TVshowCache")
        hometheater_showsList = mongoConnect("Hometheater", "ShowsList")
        if len(showListsalldb) != hometheater_showsList.count_documents({}):
            showLists = tvshow(channelName)
            refreshContainer(mode="get_shows", url=channelList)
        else:
            box(title="Not Found", message="No New Shows Was Found")
    if action == "None":
        showListsdb = getdb(dbname="tvCache.db", tablename="TVshowCache", condition=channelName, whereclause="Channel_Name", orderby="Show_Status, Show_Name")
        log(message="The action is", find=action)
        if showListsdb:
            log(message="if case in showlistdb", find=showListsdb)
            setShowDetails(showListsdb)
        elif not showListsdb:
            showLists = tvshow(channelName)
            showLists = [tuple(showlist.values()) for showlist in showLists if showlist['chname'] == channelName]
            setShowDetails(showLists)


def set_status(showname, status):
    updateDatabase(dbname="tvCache.db", tablename="TVshowCache", updatevar="Show_Status", updatevalue=status, whereclause="Show_Name", condition=showname)
    # xbmc.executebuiltin('Container.Refresh')
    

def tvshow(channelName):
    showListsdb = getdb(dbname="tvCache.db", tablename="TVshowCache")
    shownamedb = [shname[1] for shname in showListsdb] or []
    hometheater_showList = mongoConnect("Hometheater", "ShowsList")
    showLists = [showlist for showlist in hometheater_showList.find({}, {'_id' : 0})]
    channelDetail = []
    for showList in showLists:
        chname, showname, poster, backdrop, showurl, showstatus = showList.values()
        if showname not in shownamedb:
            chdet = {}
            chdet["chname"] = chname
            chdet["showname"] = showname
            chdet["poster"] = poster
            chdet["backdrop"] = backdrop
            chdet["url"] = showurl
            chdet["Show_Status"] = showstatus
            channelDetail.append(chdet)
    tvCache(channelDetail)
    return channelDetail


def episodeList(episodeUrlList, channelName):
    hometheater_episodeList = mongoConnect("Hometheater", "episodeList")
    if hometheater_episodeList is not None:
        showlistsmongodata = [data for data in hometheater_episodeList.find({'channelName' : channelName}, {"_id" : 0}).sort({'episodeDate' : -1})]
    with concurrent.futures.ThreadPoolExecutor() as executor:
        if hometheater_episodeList is not None:
            futures = [executor.submit(episodePage, episodeUrl, channelName, showname, [episodemongo for episodemongo in showlistsmongodata if episodemongo['showName'] == showname]) for showname, episodeUrl in episodeUrlList]
        else:
            futures = [executor.submit(episodePage, episodeUrl, channelName, showname) for showname, episodeUrl in episodeUrlList]
        for future in concurrent.futures.as_completed(futures):
            if future.result():
                log(message="the object to be added is", find=future.result())
                tvEpisodeCache(future.result())

def get_Episodes(showname):
    episodesdb = getdb(dbname="tvEpisodes.db", tablename="tvEpisodes", whereclause="showName", condition=showname, orderby="episodeDate DESC")
    for episode in episodesdb:
        chname, shname, title, imgurl, airingDate, episodeUrl = episode
        li = xbmcgui.ListItem(title)
        li.setArt({
            'thumb' : imgurl,
            'icon' : imgurl,
            'fanart' : imgurl
        })
        formatted_date = parser.parse(airingDate).strftime("%d/%m/%Y")
        li.setProperty("FormattedPremiered", formatted_date)
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([("Play Link 2", f'RunPlugin({build_url({"mode": "play_video", "url": episodeUrl})})'), ("Refresh Episode", f'RunPlugin({build_url({"mode": "refresh_link", "filterValue": title, "type" : "tvepisode"})})')])
        epiUrl = build_url({'mode': 'play_video', 'url': episodeUrl})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=epiUrl, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_video(episodeUrl):
    streamUrls = episodeUrl.split(", ")
    for streamUrl in streamUrls:
        if x := pick_right_url(streamUrl):
            validUrl = x
            break
        elif streamUrl == "":
            box("Playback Error", "No video found")

    li = xbmcgui.ListItem(offscreen = True)
    li.setPath(validUrl)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

def pick_right_url(testUrl):
    if not testUrl.endswith((".mp4", ".mkv", ".avi")):
        stream_Url = resolve_url(testUrl, subs=True)
        if stream_Url:
            log(message="entered hls if streamUrl section", find=testUrl)
            stream_Url = stream_Url.get('url')
            if 'hls' in stream_Url:
                stream_Url = refineTvlogyUrl(stream_Url)
            # print(f"Stream url is: {stream_Url}")
            return stream_Url
        else:
            return None
    else:
        return testUrl

        
def refineTvlogyUrl(TvlogyUrl):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0"
    }
    response = requests.get(TvlogyUrl.split('|')[0], headers=headers)
    
    # Check if the request was successful
    if response.status_code == 200:
        videoLink = response.text.splitlines()[-1]
        if videoLink.startswith("http"):
            if requests.get(videoLink, headers=headers).status_code == 200:
                return videoLink
            else:
                return None
        else:
            return None
    else:
        log(message="Failed to access the URL, status code:", find=response.status_code)
        return None

def episodePage(episodeUrl, channelname, showname, showlistsmongodata = None):
    episodeDetail = []
    showlistdb = getdb(dbname="tvEpisodes.db", tablename="tvEpisodes", condition=showname, whereclause="showName" , select="episodeTitle, episodeDate")
    showlistdatedb = [date[1] for date in showlistdb]
    showlistdbtitles = [entry[0] for entry in showlistdb]
    from datetime import datetime
    if str(datetime.today().date()) not in showlistdatedb:
        if showlistsmongodata:
            for showlistmongodata in showlistsmongodata:
                if showlistmongodata['episodeTitle'] in showlistdbtitles:
                    break
                else:
                    chname, shname, title, img, date, url = showlistmongodata.values()
                    epidet = appendepisodes(chname, shname, title, img, date, ", ".join(url))
                    episodeDetail.append(epidet)
            log(message="the episode list is", find=episodeDetail)
            return episodeDetail
        else:
            return None        

    else:
        log(message="skipped successfully", find=showname)
        return None
    
    # Fetch images in the background

def appendepisodes(channelname, showname, episode, imgPath, airingDate, urlPath):
    epidet = {}
    epidet["channelname"] = channelname
    epidet["showname"] = showname
    epidet["title"] = episode
    epidet["img"] = imgPath
    epidet["episodedate"] = airingDate
    epidet["EpisodeUrl"] = urlPath
    return epidet