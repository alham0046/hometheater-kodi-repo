import requests
from bs4 import BeautifulSoup, SoupStrainer
import re
import pymongo
import sqlite3

def mongoConnect(dbname, collection = None):
    connectdb = pymongo.MongoClient(f"mongodb://alham0046:alham789@ac-2ybb09o-shard-00-00.odsdwox.mongodb.net:27017,ac-2ybb09o-shard-00-01.odsdwox.mongodb.net:27017,ac-2ybb09o-shard-00-02.odsdwox.mongodb.net:27017/?ssl=true&replicaSet=atlas-vwia5y-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0/{dbname}")
    if connectdb:
        print("connection success")
        if not collection:
            return connectdb[dbname]
        elif collection:
            if collection not in connectdb[dbname].list_collection_names():
                return None
            return connectdb[dbname][collection]
        
# def moviesCache(dbname, tablename, moviesList = []):
#     keysList = moviesList[0].keys()
#     keys = ", ".join([f"{key} TEXT" for key in keysList])
#     conn = sqlite3.connect(dbname)
#     cur = conn.cursor()
#     fileCache = f"CREATE TABLE IF NOT EXISTS {tablename} ({keys})"
#     cur.execute(fileCache)
#     conn.commit()
#     for movies in moviesList:
#         values = movies.values()
#         cur.execute(f"INSERT INTO {tablename} VALUES ({", ".join(["?"] * len(keysList))})", (tuple(values)))
#         conn.commit()
#         # print(epiDetail["title"])
    
#     conn.close()

# hometheater_moviesList = mongoConnect("Hometheater", "moviesList")
# movieslist = hometheater_moviesList.find({}, {"_id" : 0}).sort({"$natural":-1})
# movielist = [movies for movies in movieslist]
# moviesCache(dbname="movieslist.db", tablename="movieslist", moviesList=movielist)
# # print(hometheater_moviesList.count_documents({}))
# print(movieslist)
# # keys = movielist[0].keys()
# # keys = ", ".join([f"{key} TEXT" for key in keys])
# # print(len(keys))
# # print(tuple(keys))
hometheater_moviesList = mongoConnect("Hometheater", "moviesList")
movieslistmongo = hometheater_moviesList.find({}, {"_id" : 0}).sort({"$natural":-1})
# movielist = [movies for movies in movieslistmongo if movies["movieName"] not in moviesNameListsdb]
movielist = []
for movies in movieslistmongo:
    # if movies["movieName"] not in moviesNameListsdb:
    movielist.append(movies)
print(movielist)
    


