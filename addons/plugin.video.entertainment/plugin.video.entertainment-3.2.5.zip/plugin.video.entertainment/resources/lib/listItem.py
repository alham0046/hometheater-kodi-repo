class setVideoInfoTag:
    def __init__(self, li):
        self.li = li
        self._info_tag = self.li.getVideoInfoTag()
    def videoTags(self, infoLabel:dict):
        for k, v in infoLabel.items():
            if v:
                attr_info = videoAttrs._tag_attr[k]
                setValue = attr_info['attr']
                if isinstance(v, attr_info['classinfo']):
                    value = v
                else:
                    # Convert value to the expected type
                    value = attr_info['convert'](v)
                if k == 'tmdb_id':
                    getattr(self._info_tag, setValue)(value, 'tmdb')
                else:
                    getattr(self._info_tag, setValue)(value)




class videoAttrs(setVideoInfoTag):
    _tag_attr = {
        'size': {'skip': True},  # Currently no infoTag setter for this property
        'count': {'skip': True},  # Currently no infoTag setter for this property
        'date': {'attr': 'setDateAdded', 'convert': str, 'classinfo': str},  # Unsure if this is the correct place to route this generic value
        'genre': {'attr': 'setGenres', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'country': {'attr': 'setCountries', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'year': {'attr': 'setYear', 'convert': int, 'classinfo': int},
        'episode': {'attr': 'setEpisode', 'convert': int, 'classinfo': int},
        'season': {'attr': 'setSeason', 'convert': int, 'classinfo': int},
        'sortepisode': {'attr': 'setSortEpisode', 'convert': int, 'classinfo': int},
        'sortseason': {'attr': 'setSortSeason', 'convert': int, 'classinfo': int},
        'episodeguide': {'attr': 'setEpisodeGuide', 'convert': str, 'classinfo': str},
        'showlink': {'attr': 'setShowLinks', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'top250': {'attr': 'setTop250', 'convert': int, 'classinfo': int},
        'setid': {'attr': 'setSetId', 'convert': int, 'classinfo': int},
        'tracknumber': {'attr': 'setTrackNumber', 'convert': int, 'classinfo': int},
        'rating': {'attr': 'setRating', 'convert': float, 'classinfo': float},
        'userrating': {'attr': 'setUserRating', 'convert': int, 'classinfo': int},
        'watched': {'skip': True},  # Evaluated internally in Nexus based on playcount so skip
        'playcount': {'attr': 'setPlaycount', 'convert': int, 'classinfo': int},
        'overlay': {'skip': True},  # Evaluated internally in Nexus based on playcount so skip
        'cast': {'route': 'set_info_cast'},
        'castandrole': {'route': 'set_info_cast'},
        'director': {'attr': 'setDirectors', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'mpaa': {'attr': 'setMpaa', 'convert': str, 'classinfo': str},
        'plot': {'attr': 'setPlot', 'convert': str, 'classinfo': str},
        'plotoutline': {'attr': 'setPlotOutline', 'convert': str, 'classinfo': str},
        'title': {'attr': 'setTitle', 'convert': str, 'classinfo': str},
        'originaltitle': {'attr': 'setOriginalTitle', 'convert': str, 'classinfo': str},
        'sorttitle': {'attr': 'setSortTitle', 'convert': str, 'classinfo': str},
        'duration': {'attr': 'setDuration', 'convert': int, 'classinfo': int},
        'studio': {'attr': 'setStudios', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'tagline': {'attr': 'setTagLine', 'convert': str, 'classinfo': str},
        'writer': {'attr': 'setWriters', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'tvshowtitle': {'attr': 'setTvShowTitle', 'convert': str, 'classinfo': str},
        'premiered': {'attr': 'setPremiered', 'convert': str, 'classinfo': str},
        'status': {'attr': 'setTvShowStatus', 'convert': str, 'classinfo': str},
        'set': {'attr': 'setSet', 'convert': str, 'classinfo': str},
        'setoverview': {'attr': 'setSetOverview', 'convert': str, 'classinfo': str},
        'tag': {'attr': 'setTags', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'imdbnumber': {'attr': 'setIMDBNumber', 'convert': str, 'classinfo': str},
        'code': {'attr': 'setProductionCode', 'convert': str, 'classinfo': str},
        'aired': {'attr': 'setFirstAired', 'convert': str, 'classinfo': str},
        'credits': {'attr': 'setWriters', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'lastplayed': {'attr': 'setLastPlayed', 'convert': str, 'classinfo': str},
        'album': {'attr': 'setAlbum', 'convert': str, 'classinfo': str},
        'artist': {'attr': 'setArtists', 'convert': lambda x: [x], 'classinfo': (list, tuple)},
        'votes': {'attr': 'setVotes', 'convert': int, 'classinfo': int},
        'path': {'attr': 'setPath', 'convert': str, 'classinfo': str},
        'trailer': {'attr': 'setTrailer', 'convert': str, 'classinfo': str},
        'dateadded': {'attr': 'setDateAdded', 'convert': str, 'classinfo': str},
        'mediatype': {'attr': 'setMediaType', 'convert': str, 'classinfo': str},
        'dbid': {'attr': 'setDbId', 'convert': int, 'classinfo': int},
        'tmdb_id': {'attr': 'setUniqueID', 'convert': str, 'classinfo': str},  # TMDb ID handling
    }