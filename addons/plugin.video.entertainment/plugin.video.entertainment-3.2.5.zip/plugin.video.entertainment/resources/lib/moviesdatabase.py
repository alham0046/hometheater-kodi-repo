import xbmcplugin
import xbmcgui
import xbmc
from resources.lib.urlResolver import resolve_url
from resources.lib.impfunctions import build_url, addon_handle, log, refreshContainer, show_dialog as box
from resources.lib.connectMongo import mongoConnect
from resources.utils.db_util import getdb, moviesCache
from resources.lib.listItem import setVideoInfoTag

popularOtts = ['netflix', 'hotstar', 'amazon prime', 'sonyliv', 'zee5', 'jiocinema', 'mxplayer']

def get_movieplatform():
    for ottApp in popularOtts:
        li = xbmcgui.ListItem(ottApp.upper())
        li.addContextMenuItems([("Check New Movies", f'RunPlugin({build_url({"mode": "get_movies", "url": ottApp, "action" : "addNew"})})'), ("Restore Database", f'RunPlugin({build_url({"mode": "restore_database", "dbname" : "movieslist.db", "tablename" : "movieslist"})})')])
        url = build_url({'mode': 'get_movies', 'url': ottApp})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def get_moviesList(ottApp, action = "None"):
    moviesListsdb = getdb(dbname="movieslist.db", tablename="movieslist", whereclause="moviePlatform", condition=ottApp.upper(), orderby="movieReleaseDate DESC")
    def setMovieDetails(moviesList):
        for movieList in moviesList:
            meta = {}
            name, ottplatform, releaseDate, plot, poster, backdrop, testLink , url, duration, _ = movieList
            duration = int(duration)*60 if duration else None
            li = xbmcgui.ListItem(name)
            info_tag = li.getVideoInfoTag()
            li.setArt({
                'thumb' : poster,
                'icon' : poster,
                'fanart' : backdrop
            })
            li.setProperty('VideoResolution', '1080')
            li.setProperty('PlatformOtt', ottplatform)
            meta.update({"mediatype" : "movie", "premiered" : releaseDate, "plot" : plot, "title" : name, "duration" : duration})
            info_tag = setVideoInfoTag(li=li)
            info_tag.videoTags(meta)
            li.setProperty('IsPlayable', 'true')
            li.addContextMenuItems([("Refresh Movie", f'RunPlugin({build_url({"mode": "refresh_link", "filterValue": name, "type" : "movie"})})')])
            showurl = build_url({'mode': 'play_movie', 'url': url})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
    if action == "addNew":
        movieListsalldb = getdb(dbname="movieslist.db", tablename="movieslist")
        hometheater_moviesList = mongoConnect("Hometheater", "moviesList")
        if len(movieListsalldb) != hometheater_moviesList.count_documents({}):
            moviesNameListsdb = [movies[0] for movies in movieListsalldb] or []
            movieslistmongo = hometheater_moviesList.find({}, {"_id" : 0})
            log(message="number db", find=movieslistmongo)
            movielist = []
            for movies in movieslistmongo:
                if movies["movieName"] not in moviesNameListsdb:
                    log(message="entering to movie", find=movies)
                    movielist.append(movies)
            log(message="movies appended", find=movielist)
            moviesCache(dbname="movieslist.db", tablename="movieslist", moviesList=movielist)
            refreshContainer(mode="get_movies", url=popularOtts)
        else:
            box(title="NOT FOUND", message="No New Movie Was Found")

    elif action == "None":
        if moviesListsdb:
            setMovieDetails(moviesListsdb)
        hometheater_moviesList = mongoConnect("Hometheater", "moviesList")
        if len(moviesListsdb) != hometheater_moviesList.count_documents({"moviePlatform" : ottApp.upper()}):
            moviesNameListsdb = [movies[0] for movies in moviesListsdb] or []
            movieslistmongo = hometheater_moviesList.find({"moviePlatform" : ottApp.upper()}, {"_id" : 0}).sort({"$natural":-1})
            movielist = []
            for movies in movieslistmongo:
                if movies["movieName"] not in moviesNameListsdb:
                    movielist.append(movies)
                else:
                    break
            moviesCache(dbname="movieslist.db", tablename="movieslist", moviesList=movielist)
            if moviesListsdb:
                refreshContainer(mode="get_movies", url=ottApp)
            if not moviesListsdb:
                moviesListsdb = getdb(dbname="movieslist.db", tablename="movieslist", whereclause="moviePlatform", condition=ottApp.upper(), orderby="movieReleaseDate DESC")
                setMovieDetails(moviesListsdb)

def search_movies(query):
    moviesListsdb = getdb(dbname="movieslist.db", tablename="movieslist", whereclause="movieName", condition=f"%{query.title()}%", like=True)
    for movies in moviesListsdb:
        name, ottplatform, releaseDate, plot, poster, backdrop, testLink , url, duration, _ = movies
        li = xbmcgui.ListItem(name)
        info_tag = li.getVideoInfoTag()
        li.setArt({
            'thumb' : poster,
            'icon' : poster,
            'fanart' : backdrop
        })
        li.setProperty('VideoResolution', '1080')
        info_tag.setPlot(plot)
        li.setProperty('PlatformOtt', ottplatform)
        info_tag.setPremiered(releaseDate)
        info_tag.setDuration(int(duration)*60)
        li.setProperty('IsPlayable', 'true')
        showurl = build_url({'mode': 'play_movie', 'url': url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=showurl, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def play_movie(video_url):
    log(message="The playable link is", find=video_url)
    if "gofile" in video_url:
        getUrl = resolve_url(video_url, subs=True)
        video_url = getUrl.get('url')
    li = xbmcgui.ListItem(offscreen = True)
    li.setPath(video_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

